cd dist;  PATH=../../dist/bin:$PATH LD_LIBRARY_PATH=../../dist/bin ./Squares

